# OrganizadorDeArchivos
Script de consola que permite organizar todos los archivos de un directorio en subcarpetas
