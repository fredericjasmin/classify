# Script para ordenar archivos según la extensión que tengan.

Con este sencillo script podremos organizar los archivos que tengamos en una carpeta dependiendo de la extensión que tengan.

El funcionamiento es sl siguiente:

PASO 1 - El script comprueba si existen las carpetas donde se enviarán los archivos, en caso de no encontrarlas, las crea.

PASO 2 - Se comprueban las extensiones de todos los archivos uno por uno.

PASO 3 - Se mueven los diferentes tipos de archivos en función de si son documentos, fotos, vídeos, música u otros
tipos de archivos.

Este script es ideal para automatizar la carpeta de descargas para tener todos los archivos descargados ordenados en todo momento.
