Herramienta preparada para Windows 10 para organizar archivos en masa.

